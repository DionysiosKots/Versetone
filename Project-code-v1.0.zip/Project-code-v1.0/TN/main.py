import tkinter
from tkinter import *
import tkinter.messagebox


root = Tk()

e1=StringVar()
e2=StringVar()

# Add Song Menu

def add_song():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    tkinter.Label(xor, text="Enter song name").grid(row=1)
    e2 = Entry(xor)

    e2.grid(row=1, column=1)

    tkinter.Button(xor, text="OK", command=check).grid(row=2, column=1, sticky=tkinter.W, pady=4)
    xor.mainloop()

# Check

def check():


    if e2=="gucci forema" or e2=="eye of yo mama":
        tkinter.messagebox.showinfo('ERROR', "Song already exists")
    else:
        tkinter.messagebox.showinfo('SUCCESS', "Request sent successfully")


# Song Show

def show():

    if e1=="gucci forema":
        song1()
    elif e1=="eye of yo mama":
        song2()
    else:
        tkinter.messagebox.showinfo('ERROR 404', "Song not found")


#Search A Song Menu

def search_song():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    tkinter.Label(xor, text="Enter song name").grid(row=1)
    e1=Entry(xor)

    e1.grid(row=1, column=1)

    tkinter.Button(xor, text="OK", command=show).grid(row=2,column=1,sticky=tkinter.W, pady=4)
    xor.mainloop()


#Account Menu

def account():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="-ACCOUNT-\n BYRON CABEROS\n2 Songs in library\n 5 hours in app", bg="red")
    d.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()

# Faq Menu

def faq():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="-FAQ-\nQ:How do i add to library?\nA:You don't you already have a library", bg="red")
    d.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()

# Thanks For Rating

def thank_you():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="Thank you a lot", bg="red")
    d.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()

# Eye of yo mama

def song2():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="-EYE OF YO MAMA-\nΞεσηκώνομαι, πίσω στο δρόμο Έκανα το χρόνο μου, πήρα τις ευκαιρίες μου Πήγα την απόσταση, τώρα είμαι", bg="red")
    d.pack(fill=X)

    d1 = Label(xor, text="ξανά στα πόδια μου Μόνο ένας άνθρωπος και η θέλησή του να επιβιώσει Πολλές φορές συμβαίνει πολύ γρήγορα Αλλάζεις το", bg="red")
    d1.pack(fill=X)

    d2= Label(xor, text="πάθος σου για δόξα Μην χάνετε τον έλεγχο των ονείρων του παρελθόντος Πρέπει να πολεμήσετε μόνο και μόνο για να τους", bg="red")
    d2.pack(fill=X)

    d3 = Label(xor, text="κρατήσετε στη ζωή Είναι το μάτι της ΜΑΝΑΣ ΣΟΥ", bg="red")
    d3.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()

# Gucci Forema

def song1():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="-Gucci Forema-\nΌλα καλά μέχρι που μπήκες εσύ Κι από την ώρα που σε είδα έχω εντελώς τρελαθεί", bg="red")
    d.pack(fill=X)

    p1 = Label(xor, text="Δεν είν του γούστου μου κοπέλες σαν κι εσένα αλλά Κάτι έχω πάθει τελευταία και δεν είμαι καλά\nΜαζί σου κόλλησα και δεν", bg="red")
    p1.pack(fill=X)

    p2 = Label(xor,text="μπορώ άλλη πια να σκεφτώ Δεν σε γουστάρω κι απορώ πώς μου συμβαίνει αυτό\nΎφος πολλών καρδιναλίων και μεγάλο τουπέ Για",bg="red")
    p2.pack(fill=X)

    p3 = Label(xor, text="ξεκαβάλα το, ψηλά έχεις πάρει τον αμανέ\nΈχεις μεγάλη γκάμα θαυμαστών που κάνουν ουρά Από μικρούς τυπάδες μέχρι", bg="red")
    p3.pack(fill=X)

    p4 = Label(xor, text="ματσωμένα πουρά Παίζεις με όλους και με όλα, είπα ξείπα τους λες Και θέλεις να ναι οι επιθυμίες σου γι αυτούς διαταγές", bg="red")
    p4.pack(fill=X)

    p5 = Label(xor, text="Έλα που δεν μπορώ Πλέον ν αντισταθώ Σ αυτό το gucci φόρεμα που φοράς Και στο ρυθμό που απόψε βράδυ το κορμί σου κουνάς", bg="red")
    p5.pack(fill=X)

    p6 = Label(xor, text="Έλα που δεν μπορώ Πλέον ν αντισταθώ Σ αυτό το gucci φόρεμα που φοράς Και στο ρυθμό που απόψε βράδυ το κορμί σου κουνάς", bg="red")
    p6.pack(fill=X)

    p7 = Label(xor, text="Γέννημα θρέμμα δυτικής Αττικής Έχουμε περηφάνεια εδώ εμείς και λόγο τιμής Μπουρνάζι Αιγάλεω, Περιστέρι, ξέρω ζόρι τραβάς", bg="red")
    p7.pack(fill=X)

    p8 = Label(xor, text="Μέρη που εσύ κι οι φίλες σου τα θεωρείτε μπας κλας Από την άλλη εγώ Εκάλη δεν πατάω ποτέ Γιατί είναι μέρος με γυναίκες", bg="red")
    p8.pack(fill=X)

    p9 = Label(xor, text="που έχουν ύφος μπλαζέ Με ξιπασμένα κοριτσάκια ενός πλουσίου μπαμπά Που ξέρουν μόνο χίλιους τρόπους να του παίρνουν λεφτά", bg="red")
    p9.pack(fill=X)

    p10 = Label(xor, text="Αν δε σ αρέσει το αμάξι μου μη σώσεις ποτέ Πάρε το βουτυρόπαιδο απ την Κηφισιά με BMW Που λέει το βράδυ πριν ξαπλώσει", bg="red")
    p10.pack(fill=X)

    p11 = Label(xor, text="καληνύχτα μαμά Και παριστάνει τον τυπά με τα λεφτά του μπαμπά Του μπαμπά, του μπαμπά Πάρε αυτόν, θα φας καλά, με μαμά", bg="red")
    p11.pack(fill=X)

    p12 = Label(xor, text="και μπαμπά Κήπο, πισίνα και λεφτά Να του αλείφεις βούτυρο στο ψωμί Και κατά τ άλλα εσύ να ζεις μες στη μεγάλη χλιδή Έλα", bg="red")
    p12.pack(fill=X)

    p13 = Label(xor, text="που δεν μπορώ Πλέον ν αντισταθώ Σ αυτό το gucci φόρεμα που φοράς Και στο ρυθμό που απόψε βράδυ το κορμί σου κουνάς Έλα", bg="red")
    p13.pack(fill=X)

    p14 = Label(xor, text="που δεν μπορώ Πλέον ν αντισταθώ Σ αυτό το gucci φόρεμα που φοράς Και στο ρυθμό που απόψε βράδυ το κορμί σου κουνάς", bg="red")
    p14.pack(fill=X)

    p15 = Label(xor, text="Γέννημα θρέμμα δυτικής Αττικής, γέννημα θρέμμα, γέννημα θρέμμα Ό,τι σιχαίνομαι όλα τα χεις εσύ Και μακιγιέρ κατ οίκον", bg="red")
    p15.pack(fill=X)

    p16 = Label(xor, text="και προσωπικό κομμωτή Δυο ώρες θες να σού ετοιμάσουν μανικιούρ γαλλικό Καθώς εσύ μιλάς μ ένα άλλο ψώνιο στο κινητό Θέμα", bg="red")
    p16.pack(fill=X)

    p17 = Label(xor, text="συζήτησης μαντεύω μόδα και κοσμικά Ο κόσμος καίγεται μα εσείς το δικό σας χαβά Το Vogue σ αρέσει και το Elle και το", bg="red")
    p17.pack(fill=X)

    p18 = Label(xor, text="Madame Figaro Μα αν θα σε βάλω κάτω θα σ αρέσω μόνο εγώ Μπότες ψηλές, μίνι καυτό, μωρό μου απόψε φυσάς Πρέπει οπωσδήποτε", bg="red")
    p18.pack(fill=X)

    p19 = Label(xor, text="σου λέω να γίνει κάτι με μας Εσύ απ τη μία να μού δείξεις πώς περνάς στη χλιδή Κι εγώ απ την άλλη πώς το κάνουμε στην", bg="red")
    p19.pack(fill=X)

    p20 = Label(xor, text="Καισαριανή Έλα που δεν μπορώ Πλέον ν αντισταθώ Σ αυτό το gucci φόρεμα που φοράς Και στο ρυθμό που απόψε βράδυ το κορμί", bg="red")
    p20.pack(fill=X)

    p21 = Label(xor, text="σου κουνάς Έλα που δεν μπορώ Πλέον ν αντισταθώ Σ αυτό το gucci φόρεμα που φοράς Και στο ρυθμό που απόψε βράδυ το κορμί", bg="red")
    p21.pack(fill=X)

    p22 = Label(xor, text="σου κουνάς Έλα που δεν μπορώ Πλέον ν αντισταθώ Σ αυτό το gucci φόρεμα που φοράς Και στο ρυθμό που απόψε βράδυ το κορμ", bg="red")
    p22.pack(fill=X)

    p23 = Label(xor, text="σου κουνάς Και στο ρυθμό που απόψε βράδυ το κορμί σου κουνάς Σ αυτό το gucci φόρεμα που φοράς Σ αυτό το gucci φόρεμα που", bg="red")
    p23.pack(fill=X)

    p24 = Label(xor, text="φοράς", bg="red")
    p24.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()

# Rate Us Menu

def rate_us():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="-RATE US-\nThank you for putting 5 stars cause we are so good", bg="red")
    d.pack(fill=X)

    toolbar = Frame(xor, bg="blue")

    insertButt = Button(toolbar, bg="green", text="OK", command=thank_you)
    insertButt.pack(padx=2, pady=2)

    toolbar.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()

# About Us Menu

def about_us():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="-ABOUT US-\nWe are 3 little people that love music and partyyyyyy also we are good christians", bg="red")
    d.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()

# Library Menu

def library():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="-LIBRARY-\nGucci Forema\nEye of yo mama", bg="red")
    d.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()

# Charts Menu
def Charts():
    xor = Tk()

    libmen = Menu(root, bg="blue")
    root.config(menu=libmen)

    d = Label(xor, text="-CHARTS-", bg="red")
    d.pack(fill=X)

    toolbar = Frame(xor, bg="blue")

    insertButt = Button(toolbar, bg="green", text="Gucci Forema", command=song1)
    insertButt.pack(padx=2, pady=2)

    toolbar.pack(fill=X)


    toolbar = Frame(xor, bg="blue")

    insertButt2 = Button(toolbar, bg="green", text="Eye of yo mama", command=song2)
    insertButt2.pack(padx=2, pady=2)

    toolbar.pack(fill=X)

    fr = Frame(xor, width=700, height=300, bg="blue")
    fr.pack()

    xor.mainloop()


# Menu

menu = Menu(root)
root.config(menu=menu)




s = Label(root, text="MENU", bg="red")
s.pack(fill=X)

# VersTone Label

status = Label(root, text="VerseTone", bd=1, relief=SUNKEN, anchor=W)
status.pack(side=BOTTOM, fill=X)


# Buttons

toolbar = Frame(root, bg="blue")

insertButt = Button(toolbar, bg="green", text="Search a song", command=search_song)
insertButt.pack(padx=2, pady=2)

toolbar.pack(fill=X)

toolbar = Frame(root, bg="blue")

insertButt2 = Button(toolbar, bg="green", text="Library", command=library)
insertButt2.pack(padx=2, pady=20)

toolbar.pack(fill=X)

toolbar = Frame(root, bg="blue")

insertButt3 = Button(toolbar, bg="green", text="Charts", command=Charts)
insertButt3.pack(padx=2, pady=2)

toolbar.pack(fill=X)

toolbar = Frame(root, bg="blue")

insertButt4 = Button(toolbar, bg="green", text="Account", command=account)
insertButt4.pack(padx=2, pady=20)

toolbar.pack(fill=X)

toolbar = Frame(root, bg="blue")

insertButt5 = Button(toolbar, bg="green", text="Add Song", command=add_song)
insertButt5.pack(padx=2, pady=2)

toolbar.pack(fill=X)

toolbar = Frame(root, bg="blue")

insertButt12 = Button(toolbar, bg="green", text="Exit", command=quit)
insertButt12.pack(padx=2, pady=2)

toolbar.pack(side=BOTTOM, fill=X)

toolbar = Frame(root, bg="blue")

insertButt6 = Button(toolbar, bg="green", text="Rate Us", command=rate_us)
insertButt6.pack(padx=2, pady=10)

toolbar.pack(side=BOTTOM, fill=X)

toolbar = Frame(root, bg="blue")

insertButt7 = Button(toolbar, bg="green", text="About Us", command=about_us)
insertButt7.pack(padx=2, pady=10)

toolbar.pack(side=BOTTOM, fill=X)

toolbar = Frame(root, bg="blue")

insertButt8 = Button(toolbar, bg="green", text="FAQ", command=faq)
insertButt8.pack(padx=2, pady=10)

toolbar.pack(side=BOTTOM, fill=X)

# Frame

fr = Frame(root, width=700, height=300, bg="blue")
fr.pack()

root.mainloop()